// Función flecha para calcular el IVA (en Chile es el 19%)
const iva = (a) => a * 1.19;

// Función principal del programa
function carritoDeCompras(nombre) {
    // Defino las variables total y productos para ir acumulando la compra (tanto el nombre como el costo)
    // Ocupo la variable verificador para ver si el cliente desea seguir comprando o no
    let total = 0;
    let productos = "";
    let verificador = 1;

    // Ciclo while me permite repetir el proceso hasta que el cliente no quiera comprar más
    while (verificador == 1) {

        let respuesta = parseInt(prompt("Hola " + nombre + " Ingrese el número del producto a agregar\n1. Coca-Cola - USD 5\n2. Leche - USD 3\n3. Pan - USD 2"));

        if (respuesta == 1) {
            total += 5;
            productos += " Coca-Cola /";
            alert(nombre + " usted añadió Coca-Cola.\nAhora su carro de compras tiene: " + productos + "\nSu total es: USD " + total);
            verificador = parseInt(prompt("Ingrese el número 1 si desea añadir algo más, si desea finalizar la compra ingrese cualquier tecla"));
        }
        else if (respuesta == 2) {
            total += 3;
            productos += " Leche /";
            alert(nombre + " usted añadió Leche.\nAhora su carro de compras tiene: " + productos + "\nSu total es: USD " + total);
            verificador = parseInt(prompt("Ingrese el número 1 si desea añadir algo más, si desea finalizar la compra ingrese cualquier tecla"));
        } 
        else if (respuesta == 3) {
            total += 2;
            productos += " Pan /";
            alert(nombre + " usted añadió Pan.\nAhora su carro de compras tiene: " + productos + "\nSu total es USD: " + total);
            verificador = parseInt(prompt("Ingrese el número 1 si desea añadir algo más, si desea finalizar la compra ingrese cualquier tecla"));
        } 
        else {
            alert("Error, favor ingrese un número de la lista")
        }
    }
    return ("Gracias por comprar con nosotros.\nUsted compro: " + productos + "\nEl total con iva incluído es de: USD " + iva(total).toFixed(2))

}

nombre = prompt("Hola, favor ingrese su nombre: ");
alert(carritoDeCompras(nombre));